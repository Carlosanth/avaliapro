// supabase/functions/criar-checkout-sessao/index.ts
//
// Chamada pelo admin logado (botão "Assinar" em Configurações → Assinatura).
//
// NOTA (jul/2026): antes, o preço vinha de Price IDs fixos guardados nas
// secrets STRIPE_PRICE_ESSENCIAL/STRIPE_PRICE_PROFISSIONAL — isso exigia
// entrar no Stripe Dashboard toda vez que o preço mudava. Agora o valor e
// os limites vêm da tabela planos_config (Supabase).
//
// NOTA 2 (jul/2026): dois caminhos diferentes, dependendo se a empresa já
// tem assinatura ativa ou não:
//   - SEM assinatura ativa (trial, primeira vez): cria uma sessão de
//     Checkout normal — precisa coletar o cartão do cliente, então precisa
//     do redirecionamento pro Stripe.
//   - JÁ TEM assinatura ativa (trocando de plano): atualiza a assinatura
//     existente DIRETO via API, com rateio (proration_behavior:
//     'create_prorations') — cobra só a diferença proporcional na hora, no
//     cartão que já está salvo. Não precisa de link nem redirecionamento;
//     a troca já sai aplicada na resposta desta function.
//
// Precisa das secrets: STRIPE_SECRET_KEY, APP_URL, SERVICE_ROLE_KEY.
//
// Deploy: supabase functions deploy criar-checkout-sessao

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14?target=deno';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
    const appUrl = Deno.env.get('APP_URL');
    if (!stripeSecretKey || !appUrl) {
      return json({ ok: false, error: 'Stripe ainda não configurado no servidor (faltam secrets).' }, 200);
    }

    const { plano } = await req.json();
    if (plano !== 'essencial' && plano !== 'profissional') {
      return json({ ok: false, error: 'Plano inválido.' });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SERVICE_ROLE_KEY')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const authHeader = req.headers.get('Authorization') || '';
    if (!authHeader) return json({ ok: false, error: 'Não autenticado.' });

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const callerClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user: callerUser }, error: callerErr } = await callerClient.auth.getUser();
    if (callerErr || !callerUser) return json({ ok: false, error: 'Sessão inválida.' });

    const { data: callerProfile } = await adminClient.from('profiles').select('empresa_id, papel, ativo, email').eq('id', callerUser.id).single();
    if (!callerProfile || !callerProfile.ativo || !['admin', 'admin_master'].includes(callerProfile.papel)) {
      return json({ ok: false, error: 'Apenas administradores podem assinar um plano.' });
    }

    const { data: empresa } = await adminClient
      .from('empresas').select('id, nome, status, stripe_customer_id, stripe_subscription_id').eq('id', callerProfile.empresa_id).single();
    if (!empresa) return json({ ok: false, error: 'Empresa não encontrada.' });

    const { data: planoConfig, error: planoErr } = await adminClient
      .from('planos_config')
      .select('nome, preco, limite_fornecedores, limite_admins')
      .eq('chave', plano)
      .single();

    if (planoErr || !planoConfig) {
      return json({ ok: false, error: 'Plano não encontrado na configuração. Fale com o suporte.' });
    }

    const stripe = new Stripe(stripeSecretKey, { apiVersion: '2024-06-20' });

    const metadataComum = {
      empresa_id: empresa.id,
      plano,
      limite_fornecedores: planoConfig.limite_fornecedores == null ? '' : String(planoConfig.limite_fornecedores),
      limite_admins: planoConfig.limite_admins == null ? '' : String(planoConfig.limite_admins),
      valor_mensal: String(planoConfig.preco),
    };

    // ---------- Já tem assinatura ativa: atualiza direto, com rateio ----------
    if (empresa.status === 'ativa' && empresa.stripe_subscription_id) {
      const subscription = await stripe.subscriptions.retrieve(empresa.stripe_subscription_id);
      const itemAtual = subscription.items.data[0];

      // Mesma regra do Stripe: update de assinatura existente não aceita
      // product_data inline, só product (ID de um produto ATIVO). Cria um
      // produto novo em vez de reaproveitar o antigo, que pode estar
      // desativado no Stripe.
      const produtoPlano = await stripe.products.create({
        name: `HomologPro ${planoConfig.nome}`,
      });

      const subscriptionAtualizada = await stripe.subscriptions.update(empresa.stripe_subscription_id, {
        items: [{
          id: itemAtual.id,
          price_data: {
            currency: 'brl',
            unit_amount: Math.round(Number(planoConfig.preco) * 100),
            recurring: { interval: 'month' },
            product: produtoPlano.id,
          },
        }],
        proration_behavior: 'create_prorations',
        metadata: metadataComum,
      });

      await adminClient.from('empresas').update({
        plano,
        limite_fornecedores: planoConfig.limite_fornecedores,
        limite_admins: planoConfig.limite_admins,
        valor_mensal_atual: Number(planoConfig.preco),
        proxima_cobranca_em: new Date(subscriptionAtualizada.current_period_end * 1000).toISOString(),
        proximo_valor_mensal: null,
        proximo_reajuste_em: null,
      }).eq('id', empresa.id);

      return json({ ok: true, trocaImediata: true, mensagem: `Plano trocado! A diferença proporcional foi cobrada no cartão salvo.` });
    }

    // ---------- Sem assinatura ativa ainda: fluxo normal de checkout ----------
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{
        price_data: {
          currency: 'brl',
          unit_amount: Math.round(Number(planoConfig.preco) * 100),
          recurring: { interval: 'month' },
          product_data: { name: `HomologPro ${planoConfig.nome}` },
        },
        quantity: 1,
      }],
      customer: empresa.stripe_customer_id || undefined,
      customer_email: empresa.stripe_customer_id ? undefined : callerProfile.email,
      success_url: `${appUrl}/index.html?checkout=sucesso`,
      cancel_url: `${appUrl}/index.html?checkout=cancelado`,
      metadata: metadataComum,
      subscription_data: { metadata: metadataComum },
    });

    return json({ ok: true, trocaImediata: false, url: session.url });
  } catch (e) {
    return json({ ok: false, error: String(e) });
  }
});
