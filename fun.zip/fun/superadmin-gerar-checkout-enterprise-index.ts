// supabase/functions/superadmin-gerar-checkout-enterprise/index.ts
//
// Chamada pelo admin-plataforma.html (painel do superadmin). Recebe a
// composição escolhida pro Enterprise de uma empresa específica (valor
// base + quais pacotes do catálogo, e quantos de cada), calcula o total
// mensal (dinheiro E limites).
//
// NOTA (jul/2026): dois caminhos, dependendo se a empresa já tem
// assinatura ativa:
//   - JÁ TEM assinatura ativa (de qualquer plano, inclusive Enterprise
//     ajustado de novo): atualiza o valor recorrente da assinatura (vale
//     a partir do próximo ciclo) e gera uma FATURA AVULSA com o valor da
//     diferença proporcional — devolve um link (hosted_invoice_url) pro
//     cliente pagar como quiser. Pagar essa fatura avulsa com outro cartão
//     não troca o cartão padrão da assinatura (só troca se o cliente
//     marcar a opção de salvar na própria página da fatura).
//   - SEM assinatura ativa ainda (primeira vez indo pra Enterprise): gera
//     um link de checkout normal — precisa coletar o cartão pela primeira
//     vez, então precisa do cliente completar o pagamento.
//
// Exige super admin — mesmo padrão de segurança das outras functions
// superadmin-*.
//
// Precisa das secrets: STRIPE_SECRET_KEY, APP_URL, SERVICE_ROLE_KEY.
//
// Deploy: supabase functions deploy superadmin-gerar-checkout-enterprise

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14?target=deno';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function jsonError(message: string, status: number) {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status,
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return jsonError('Não autenticado.', 401);

    const { empresaId, valorBase, pacotes } = await req.json();
    // pacotes esperado: [{ pacoteId: 'uuid', quantidade: 2 }, ...]
    if (!empresaId) return jsonError('Faltam dados.', 400);
    const valorBaseNum = Number(valorBase) || 0;
    if (valorBaseNum < 0) return jsonError('Valor base inválido.', 400);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SERVICE_ROLE_KEY')!;
    const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
    const appUrl = Deno.env.get('APP_URL');

    if (!stripeSecretKey || !appUrl) return jsonError('Stripe ainda não configurado no servidor.', 200);

    const callerClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user: callerUser }, error: callerErr } = await callerClient.auth.getUser();
    if (callerErr || !callerUser) return jsonError('Sessão inválida.', 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    const { data: superAdmin } = await adminClient
      .from('super_admins').select('user_id').eq('user_id', callerUser.id).maybeSingle();
    if (!superAdmin) return jsonError('Acesso negado.', 403);

    const { data: empresa } = await adminClient
      .from('empresas').select('id, nome, status, stripe_customer_id, stripe_subscription_id').eq('id', empresaId).single();
    if (!empresa) return jsonError('Empresa não encontrada.', 404);

    // Busca os pacotes escolhidos no catálogo (nunca confia no preço/qtd
    // que o front manda — só confia no ID, o valor vem do banco).
    const pacotesEscolhidos: { pacoteId: string; quantidade: number }[] = Array.isArray(pacotes) ? pacotes : [];
    const pacoteIds = pacotesEscolhidos.map(p => p.pacoteId).filter(Boolean);

    let pacotesCatalogo: any[] = [];
    if (pacoteIds.length) {
      const { data: catalogo, error: catErr } = await adminClient
        .from('pacotes_config').select('id, tipo, quantidade, preco, nome_exibicao').in('id', pacoteIds);
      if (catErr) return jsonError('Erro ao buscar pacotes: ' + catErr.message, 500);
      pacotesCatalogo = catalogo || [];
    }

    let valorTotal = valorBaseNum;
    let limiteFornecedores = 0;
    let limiteAdmins = 0;
    const composicaoDetalhada: any[] = [];

    for (const escolha of pacotesEscolhidos) {
      const pacote = pacotesCatalogo.find(p => p.id === escolha.pacoteId);
      if (!pacote) continue;
      const qtdVezes = Math.max(1, Number(escolha.quantidade) || 1);

      valorTotal += Number(pacote.preco) * qtdVezes;
      const capacidadeTotal = pacote.quantidade * qtdVezes;
      if (pacote.tipo === 'fornecedor') limiteFornecedores += capacidadeTotal;
      if (pacote.tipo === 'admin') limiteAdmins += capacidadeTotal;

      composicaoDetalhada.push({
        pacoteId: pacote.id, nome: pacote.nome_exibicao, tipo: pacote.tipo,
        quantidadeEscolhida: qtdVezes, capacidadeTotal, valorTotal: Number(pacote.preco) * qtdVezes,
      });
    }

    if (valorTotal <= 0) return jsonError('O valor total precisa ser maior que zero.', 400);

    const composicaoSnapshot = { valorBase: valorBaseNum, pacotes: composicaoDetalhada, calculadoEm: new Date().toISOString() };
    const metadataComum = {
      empresa_id: empresa.id,
      plano: 'enterprise',
      limite_fornecedores: String(limiteFornecedores),
      limite_admins: String(limiteAdmins),
      valor_mensal: String(valorTotal),
    };

    const stripe = new Stripe(stripeSecretKey, { apiVersion: '2024-06-20' });

    // ---------- Já tem assinatura ativa: ajusta o valor recorrente e gera
    // um link de fatura avulsa pra cobrar a diferença proporcional ----------
    // (em vez de cobrar automático no cartão salvo: o cliente escolhe como
    // pagar essa diferença, e — diferente do Checkout — pagar essa fatura
    // avulsa com outro cartão NÃO troca o cartão padrão da assinatura,
    // a menos que o próprio cliente marque a opção de salvar na página.)
    if (empresa.status === 'ativa' && empresa.stripe_subscription_id) {
      const subscription = await stripe.subscriptions.retrieve(empresa.stripe_subscription_id);
      const itemAtual = subscription.items.data[0];

      // Ao atualizar uma assinatura existente, o Stripe não aceita
      // `product_data` (criação inline) dentro de price_data — só
      // `product`, apontando pra um produto que já existe e esteja ATIVO.
      // Reaproveitar o produto do item atual é arriscado (pode ter sido
      // desativado no Stripe por qualquer motivo), então cria um produto
      // novo a cada troca — é rápido e não depende de estado externo.
      const produtoEnterprise = await stripe.products.create({
        name: `HomologPro Enterprise — ${empresa.nome}`,
      });

      // Atualiza o valor recorrente da assinatura (vale a partir do
      // próximo ciclo) e deixa o Stripe calcular e guardar a diferença
      // proporcional como item de fatura PENDENTE (create_prorations) —
      // ela ainda não foi cobrada de ninguém nesse ponto.
      const subscriptionAtualizada = await stripe.subscriptions.update(empresa.stripe_subscription_id, {
        items: [{
          id: itemAtual.id,
          price_data: {
            currency: 'brl',
            unit_amount: Math.round(valorTotal * 100),
            recurring: { interval: 'month' },
            product: produtoEnterprise.id,
          },
        }],
        proration_behavior: 'create_prorations',
        metadata: metadataComum,
      });

      // Gera uma fatura avulsa AGORA reunindo esse item de rateio pendente
      // — em vez de deixar ele parado esperando a próxima fatura do ciclo.
      // collection_method 'send_invoice' = não cobra ninguém sozinho, só
      // gera o link (hosted_invoice_url) pro cliente pagar quando quiser.
      const faturaDiferenca = await stripe.invoices.create({
        customer: empresa.stripe_customer_id!,
        subscription: empresa.stripe_subscription_id,
        collection_method: 'send_invoice',
        days_until_due: 3,
        description: `Ajuste de plano Enterprise — ${empresa.nome}`,
        auto_advance: false,
      });

      // finalizeInvoice força a fatura a ficar pronta pra pagamento (status
      // "open") na hora — sem isso, com send_invoice ela só ficaria pronta
      // ~1h depois, e não teríamos o link pra devolver já.
      const faturaFinalizada = await stripe.invoices.finalizeInvoice(faturaDiferenca.id);

      await adminClient.from('empresas').update({
        plano: 'enterprise',
        limite_fornecedores: limiteFornecedores,
        limite_admins: limiteAdmins,
        valor_mensal_atual: valorTotal,
        proxima_cobranca_em: new Date(subscriptionAtualizada.current_period_end * 1000).toISOString(),
        proximo_valor_mensal: null,
        proximo_reajuste_em: null,
        enterprise_composicao: composicaoSnapshot,
        enterprise_valor_mensal: valorTotal,
      }).eq('id', empresaId);

      await adminClient.from('super_admin_logs').insert({
        super_admin_id: callerUser.id,
        empresa_id: empresaId,
        acao: 'enterprise_atualizado_fatura_diferenca',
        detalhe: JSON.stringify({ valorTotal, limiteFornecedores, limiteAdmins, faturaId: faturaFinalizada.id }),
      });

      return new Response(JSON.stringify({
        ok: true, trocaImediata: false, url: faturaFinalizada.hosted_invoice_url,
        valorTotal, limiteFornecedores, limiteAdmins,
        mensagem: 'Plano atualizado! Manda esse link pro cliente pagar a diferença proporcional.',
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });
    }

    // ---------- Sem assinatura ativa ainda: gera link de checkout normal ----------
    await adminClient.from('empresas').update({
      enterprise_composicao: composicaoSnapshot,
      enterprise_valor_mensal: valorTotal,
    }).eq('id', empresaId);

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{
        price_data: {
          currency: 'brl',
          unit_amount: Math.round(valorTotal * 100),
          recurring: { interval: 'month' },
          product_data: { name: `HomologPro Enterprise — ${empresa.nome}` },
        },
        quantity: 1,
      }],
      customer: empresa.stripe_customer_id || undefined,
      success_url: `${appUrl}/index.html?checkout=sucesso`,
      cancel_url: `${appUrl}/index.html?checkout=cancelado`,
      metadata: metadataComum,
      subscription_data: { metadata: metadataComum },
    });

    await adminClient.from('super_admin_logs').insert({
      super_admin_id: callerUser.id,
      empresa_id: empresaId,
      acao: 'checkout_enterprise_gerado',
      detalhe: JSON.stringify({ valorTotal, limiteFornecedores, limiteAdmins }),
    });

    return new Response(JSON.stringify({
      ok: true, trocaImediata: false, url: session.url, valorTotal, limiteFornecedores, limiteAdmins,
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });
  } catch (e) {
    return jsonError('Erro inesperado: ' + (e as Error).message, 500);
  }
});
