// ============ MÓDULO CONFERÊNCIA ============
// Formulário separado do de Avaliar Produto — pensado pra quem só confere
// uma PARTE do recebimento (ex: almoxarifado conferindo temperatura,
// transportadora), sem ver o resto do sistema. Liga/desliga por usuário
// como qualquer outro módulo (MODULOS_MENU / permissoesModulos).
//
// Junção com a avaliação de produto (js/avaliar.js) é OPCIONAL e ADITIVA,
// feita por NF + fornecedor (ver buscarConferencia em core.js):
//   - critério tipo 'sim_nao': se "Não", desconta ponto fixo na nota geral.
//   - critério tipo 'nota' (0 a 10): se o NOME bater com um critério do seu
//     formulário de produto, preenche e trava esse campo automaticamente lá.
//   - critério tipo 'texto': só informativo, não pontua nem trava nada.

let _abaConferencia = 'lancar';

function renderAdConferencia() {
  const wrap = document.getElementById('ad-page-conferencia');
  wrap.innerHTML = `
    <div class="page-header"><div><h2>Conferência</h2><p>Confira o recebimento (temperatura, transportadora, etc.) — some automático na avaliação de produto pela mesma nota fiscal.</p></div></div>
    <div class="tabs" style="margin-bottom:16px">
      <button class="tab ${_abaConferencia === 'lancar' ? 'active' : ''}" onclick="mudarAbaConferencia('lancar', this)">Fazer conferência</button>
      <button class="tab ${_abaConferencia === 'criterios' ? 'active' : ''}" onclick="mudarAbaConferencia('criterios', this)">Critérios</button>
    </div>
    <div id="conferencia-tab-lancar" style="display:${_abaConferencia === 'lancar' ? 'block' : 'none'}"></div>
    <div id="conferencia-tab-criterios" style="display:${_abaConferencia === 'criterios' ? 'block' : 'none'}"></div>
  `;
  if (_abaConferencia === 'lancar') renderLancarConferenciaTab();
  else renderCriteriosConferenciaTab();
}

function mudarAbaConferencia(aba, btn) {
  _abaConferencia = aba;
  document.querySelectorAll('#ad-page-conferencia .tab').forEach(t => t.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('conferencia-tab-lancar').style.display = aba === 'lancar' ? 'block' : 'none';
  document.getElementById('conferencia-tab-criterios').style.display = aba === 'criterios' ? 'block' : 'none';
  if (aba === 'lancar') renderLancarConferenciaTab();
  else renderCriteriosConferenciaTab();
}

// ---------- Fazer conferência ----------
function renderLancarConferenciaTab() {
  const d = db();
  const wrap = document.getElementById('conferencia-tab-lancar');
  const criteriosAtivos = d.criteriosConferencia.filter(c => c.ativo);

  if (!criteriosAtivos.length) {
    wrap.innerHTML = `<div class="empty-state"><p>Cadastre ao menos um critério ativo na aba "Critérios" antes de conferir um recebimento.</p></div>`;
    return;
  }

  window._fornecedorConferencia = { id: null, cnpj: '', novo: false };
  const hoje = new Date();

  wrap.innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="card-title">Conferir recebimento</div>
      <div class="form-row three">
        <div class="form-group">
          <label>CNPJ do fornecedor</label>
          <div style="display:flex; gap:6px">
            <input type="text" id="cf-cnpj" placeholder="00.000.000/0000-00" oninput="this.value = formatarCNPJ(this.value)" style="flex:1">
            <button type="button" class="btn btn-secondary btn-sm" onclick="buscarFornecedorPorCnpjConferencia()">🔍 Buscar</button>
          </div>
        </div>
        <div class="form-group">
          <label>Nome do fornecedor</label>
          <input type="text" id="cf-nome-fornecedor" placeholder="Busque o CNPJ primeiro" disabled>
          <div id="cf-status-fornecedor" style="margin-top:6px; font-size:11px"></div>
        </div>
        <div class="form-group"><label>Nº da Nota Fiscal</label><input type="text" id="cf-nf" placeholder="Ex: 117743"></div>
        <div class="form-group"><label>Data</label><input type="date" id="cf-data" value="${hoje.toISOString().slice(0,10)}"></div>
      </div>
      <p style="font-size:12px; font-weight:600; color:var(--text-sec); margin:14px 0 8px">Critérios</p>
      <div class="form-row three" id="cf-criterios">
        ${criteriosAtivos.map(c => `
          <div class="form-group">
            <label>${c.nome}${c.tipo === 'sim_nao' ? ` <span style="color:var(--text-muted); font-weight:400">(desconta ${c.desconto_se_nao} se "Não")</span>` : ''}</label>
            ${c.tipo === 'sim_nao' ? `
              <select class="cf-resposta-input" data-criterio-id="${c.id}" data-tipo="sim_nao">
                <option value="sim">Sim</option>
                <option value="nao">Não</option>
              </select>
            ` : c.tipo === 'nota' ? `
              <input type="number" min="0" max="10" step="0.5" class="cf-resposta-input" data-criterio-id="${c.id}" data-tipo="nota" placeholder="0 a 10">
            ` : `
              <input type="text" class="cf-resposta-input" data-criterio-id="${c.id}" data-tipo="texto">
            `}
          </div>
        `).join('')}
      </div>
      <button class="btn btn-primary" style="margin-top:16px" onclick="salvarConferencia()">Salvar conferência</button>
    </div>
    <div class="card">
      <div class="card-title">Conferências lançadas</div>
      ${renderListaConferenciasHtml()}
    </div>
  `;
}

function renderListaConferenciasHtml() {
  const d = db();
  if (!d.conferencias.length) return '<div class="empty-state"><p>Nenhuma conferência lançada ainda.</p></div>';
  return `
    <table>
      <thead><tr><th>Fornecedor</th><th>NF</th><th>Data</th><th>Desconto</th><th>Conferido por</th></tr></thead>
      <tbody>
        ${d.conferencias.slice(0, 50).map(c => {
          const forn = d.fornecedores.find(f => f.id === c.fornecedorId);
          return `<tr>
            <td>${forn ? forn.nome : '—'}</td>
            <td>${c.numeroNf}</td>
            <td>${fmtDataSimples(c.data)}</td>
            <td>${c.descontoTotal > 0 ? `<span style="color:var(--danger)">-${c.descontoTotal}</span>` : '—'}</td>
            <td style="font-size:12px; color:var(--text-muted)">${c.enviadoPorEmail || '—'}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  `;
}

function fmtDataSimples(iso) {
  if (!iso) return '—';
  const [ano, mes, dia] = iso.split('-');
  return `${dia}/${mes}/${ano}`;
}

async function buscarFornecedorPorCnpjConferencia() {
  const cnpjInput = document.getElementById('cf-cnpj');
  const cnpjLimpo = cnpjInput.value.replace(/\D/g, '');
  const nomeInput = document.getElementById('cf-nome-fornecedor');
  const statusEl = document.getElementById('cf-status-fornecedor');

  if (cnpjLimpo.length !== 14) { toast('CNPJ inválido.'); return; }

  const d = db();
  const existente = d.fornecedores.find(f => (f.cnpj || '').replace(/\D/g, '') === cnpjLimpo);
  if (existente) {
    window._fornecedorConferencia = { id: existente.id, cnpj: cnpjLimpo, novo: false };
    nomeInput.value = existente.nome;
    statusEl.innerHTML = '<span style="color:var(--success); font-weight:600">🟢 Fornecedor já cadastrado</span>';
    return;
  }

  window._fornecedorConferencia = { id: null, cnpj: cnpjLimpo, novo: true };
  nomeInput.disabled = false;
  nomeInput.value = '';
  statusEl.innerHTML = '<span style="color:var(--warn); font-weight:600">🟢 Novo — será cadastrado ao salvar</span>';
}

async function salvarConferencia() {
  const d = db();
  const estado = window._fornecedorConferencia;
  const data = document.getElementById('cf-data').value;
  const numeroNf = document.getElementById('cf-nf').value.trim();

  if (!estado || (!estado.id && !estado.novo)) { toast('Busque o CNPJ do fornecedor antes de conferir.'); return; }
  if (!data) { toast('Informe a data.'); return; }
  if (!numeroNf) { toast('Informe o número da nota fiscal.'); return; }

  let nomeFornecedor = estado.id
    ? (d.fornecedores.find(f => f.id === estado.id)?.nome || '')
    : document.getElementById('cf-nome-fornecedor').value.trim();
  if (!estado.id && !nomeFornecedor) { toast('Informe o nome do fornecedor.'); return; }

  const criteriosAtivos = d.criteriosConferencia.filter(c => c.ativo);
  const respostas = [];
  let descontoTotal = 0;
  let faltando = false;

  document.querySelectorAll('.cf-resposta-input').forEach(inp => {
    const criterio = criteriosAtivos.find(c => c.id === inp.dataset.criterioId);
    if (!criterio) return;
    if (inp.value === '') { faltando = true; return; }

    let valor = inp.value;
    let desconto = 0;
    if (criterio.tipo === 'sim_nao') {
      if (valor === 'nao') desconto = Number(criterio.desconto_se_nao) || 0;
    } else if (criterio.tipo === 'nota') {
      valor = parseFloat(valor);
    }
    descontoTotal += desconto;
    respostas.push({ criterioId: criterio.id, nome: criterio.nome, tipo: criterio.tipo, valor, desconto });
  });

  if (faltando || !respostas.length) { toast('Preencha todos os critérios.'); return; }

  let fornecedorId = estado.id;
  if (!fornecedorId) {
    const { data: novoForn, error: errForn } = await supabaseClient.from('fornecedores').insert({
      empresa_id: currentUser.empresaId, nome: nomeFornecedor, cnpj: formatarCNPJ(estado.cnpj),
      tipo: 'produto', ativo: true, diverso: true, campos_custom: {},
    }).select().single();
    if (errForn) { toast('Erro ao cadastrar fornecedor: ' + errForn.message); return; }
    fornecedorId = novoForn.id;
    await carregarFornecedores();
  }

  const { error } = await supabaseClient.from('conferencias').insert({
    empresa_id: currentUser.empresaId,
    fornecedor_id: fornecedorId,
    usuario_id: currentUser.id,
    data,
    numero_nf: numeroNf,
    respostas,
    desconto_total: descontoTotal,
    enviado_por_email: currentUser.email,
  });

  if (error) { toast('Erro ao salvar conferência: ' + error.message); return; }

  addLog('conferencia_lancada', `${currentUser.email} lançou conferência da NF ${numeroNf} do fornecedor "${nomeFornecedor}"`);
  toast('Conferência salva!');
  await carregarConferencias();
  renderLancarConferenciaTab();
}

// ---------- Critérios (config) ----------
function renderCriteriosConferenciaTab() {
  const d = db();
  const wrap = document.getElementById('conferencia-tab-criterios');
  wrap.innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="card-title">Novo critério</div>
      <div class="form-row three">
        <div class="form-group"><label>Nome</label><input type="text" id="cc-nome" placeholder="Ex: Temperatura adequada"></div>
        <div class="form-group">
          <label>Tipo</label>
          <select id="cc-tipo" onchange="document.getElementById('cc-desconto-wrap').style.display = this.value === 'sim_nao' ? 'block' : 'none'">
            <option value="sim_nao">Sim/Não (desconta ponto se "Não")</option>
            <option value="nota">Nota de 0 a 10 (liga com critério de mesmo nome no Avaliar Produto)</option>
            <option value="texto">Texto livre (só informativo)</option>
          </select>
        </div>
        <div class="form-group" id="cc-desconto-wrap"><label>Desconto se "Não"</label><input type="number" id="cc-desconto" min="0" step="0.5" value="1"></div>
      </div>
      <button class="btn btn-primary" style="margin-top:10px" onclick="addCriterioConferencia()">Adicionar critério</button>
    </div>
    <div class="card">
      <div class="card-title">Critérios cadastrados (${d.criteriosConferencia.length})</div>
      ${!d.criteriosConferencia.length ? '<div class="empty-state"><p>Nenhum critério cadastrado ainda.</p></div>' : `
        <table>
          <thead><tr><th>Nome</th><th>Tipo</th><th>Desconto</th><th>Ativo</th><th></th></tr></thead>
          <tbody>
            ${d.criteriosConferencia.map(c => `<tr>
              <td>${c.nome}</td>
              <td>${c.tipo === 'sim_nao' ? 'Sim/Não' : c.tipo === 'nota' ? 'Nota (0-10)' : 'Texto'}</td>
              <td>${c.tipo === 'sim_nao' ? c.desconto_se_nao : '—'}</td>
              <td><input type="checkbox" ${c.ativo ? 'checked' : ''} onchange="toggleCriterioConferenciaAtivo('${c.id}', this.checked)"></td>
              <td><button class="btn btn-danger btn-sm" onclick="excluirCriterioConferencia('${c.id}')">Excluir</button></td>
            </tr>`).join('')}
          </tbody>
        </table>
      `}
    </div>
  `;
}

async function addCriterioConferencia() {
  const nome = document.getElementById('cc-nome').value.trim();
  const tipo = document.getElementById('cc-tipo').value;
  const desconto = parseFloat(document.getElementById('cc-desconto').value) || 0;
  if (!nome) { toast('Informe o nome do critério.'); return; }

  const { error } = await supabaseClient.from('criterios_conferencia').insert({
    empresa_id: currentUser.empresaId, nome, tipo, desconto_se_nao: desconto, ativo: true,
  });
  if (error) { toast('Erro ao adicionar critério: ' + error.message); return; }

  addLog('criterio_conferencia_criado', `${currentUser.email} criou o critério de conferência "${nome}"`);
  await carregarCriteriosConferencia();
  renderCriteriosConferenciaTab();
}

async function toggleCriterioConferenciaAtivo(id, ativo) {
  const { error } = await supabaseClient.from('criterios_conferencia').update({ ativo }).eq('id', id);
  if (error) { toast('Erro ao atualizar critério: ' + error.message); return; }
  await carregarCriteriosConferencia();
  renderCriteriosConferenciaTab();
}

async function excluirCriterioConferencia(id) {
  if (!confirm('Excluir esse critério? Conferências já lançadas não são afetadas (ficam com a foto de quando foram feitas).')) return;
  const { error } = await supabaseClient.from('criterios_conferencia').delete().eq('id', id);
  if (error) { toast('Erro ao excluir critério: ' + error.message); return; }
  await carregarCriteriosConferencia();
  renderCriteriosConferenciaTab();
}
